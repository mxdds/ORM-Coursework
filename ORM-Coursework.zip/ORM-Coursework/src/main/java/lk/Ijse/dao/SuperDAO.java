package lk.Ijse.dao;

public interface SuperDAO {
}
