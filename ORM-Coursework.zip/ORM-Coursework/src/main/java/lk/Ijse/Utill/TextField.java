package lk.Ijse.Utill;

public enum TextField {
    USERNAME,NAME,ADDRESS,TEL,PASSWORD,PRICE,QTY,EMAIL,DURATION
}
