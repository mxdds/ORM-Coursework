package lk.Ijse;
public class Wrapper {
    public static void main(String[] args) {
            Launcher.main(args);
    }
}