package lk.Ijse.bo;

public interface SuperBo {
}
